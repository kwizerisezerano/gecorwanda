<?php
// Database connection
require 'config.php';

// Fetch beneficiaries data
$sql = "SELECT * FROM members";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$beneficiaries = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GECO RWANDA - Manage Projects</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    
    <!-- SweetAlert CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon" />
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet" />
    <link href="assets/vendor/aos/aos.css" rel="stylesheet" />
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet" />
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet" />

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet" />

    <style>
        /* Centering the upload container */
        .upload-container {
            max-width: 500px;
            margin: 100px auto;
            padding: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .upload-container h3 {
            color: rgb(161, 83, 164); /* Purple heading */
            font-weight: 700;
            margin-bottom: 20px;
        }

        .btn-upload {
            background-color: rgb(161, 83, 164); /* Purple button */
            border: none;
        }

        .btn-upload:hover {
            background-color: #5a3791; /* Darker purple on hover */
        }

        /* Project list styling */
        .project-list {
            margin-top: 20px;
        }

        .project-list ul {
            list-style-type: none;
            padding: 0;
        }

        .project-list li {
            background-color: #f1f1f1;
            margin: 5px 0;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-actions {
            background-color: rgb(161, 83, 164);
            border: none;
            color: white;
        }

        .btn-actions:hover {
            background-color: #5a3791;
        }
    </style>
</head>
<body class="index-page">

    <!-- Header Section -->
    <header id="header" class="header d-flex align-items-center fixed-top">
        <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
            <a href="index.html" class="logo d-flex align-items-center">
                <img src="assets/img/logo.png" alt="GECO RWANDA Logo" />
                <h1 class="sitename">GECO RWANDA</h1>
            </a>
            <nav id="navmenu" class="navmenu">
            <ul>
                    <li><a href="index.php" class="active">Home</a></li>
                     <li><a href="view_projects.php" >Projects</a></li>                    
                    <li><a href="view_beneficiaries.php">Beneficiaries</a></li>
                    <li><a href="upload_file.php">Upload Documents</a></li>
                    <!-- <li><a href="projects.php">Add Projects</a></li> -->
                    <li><a href="view_donation.php">Manage donation</a></li>
                    <li><a href="view_members.php">Manage members</a></li>
                    <!-- <li><a href="view_members.php">Manage Members</a></li> -->
                    <li><a href="parteners.php">Partners</a></li>
                    
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>
        </div>
    </header>

     <!-- Beneficiaries Table Section -->
     <div class="container my-5">
      
        
        <!-- Table to Display Beneficiaries -->
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                  <th colspan="9">  <h3 class="text-center mt-5">Manage Members</h3></th></tr>
                  <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone Number</th>
                    <th>ID No. Type</th>
                    <th>ID Number</th>
                    <th>Role</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($beneficiaries as $beneficiary): ?>
                    <tr>
                        <td><?= htmlspecialchars($beneficiary['id']) ?></td>
                        <td><?= htmlspecialchars($beneficiary['first_name']) ?></td>
                        <td><?= htmlspecialchars($beneficiary['last_name']) ?></td>
                        <td><?= htmlspecialchars($beneficiary['phone_number']) ?></td>
                        <td><?= htmlspecialchars($beneficiary['idno_type']) ?></td>
                        <td><?= htmlspecialchars($beneficiary['idno']) ?></td>
                         <td><?= htmlspecialchars($beneficiary['role']) ?></td>

                        <td><?= htmlspecialchars($beneficiary['created_at']) ?></td>
                        <td>
                            <!-- Action buttons (Update and Delete) -->
                              <button class="btn btn-upload btn-sm" ><a class="text-white " href="members.php">Add members</a></button>
                            <button class="btn btn-warning btn-sm" onclick="updateBeneficiary(<?= $beneficiary['id'] ?>)">Update</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteBeneficiary(<?= $beneficiary['id'] ?>)">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- JavaScript for Update and Delete -->
    <script>
        function updateBeneficiary(id) {
            window.location.href = `update_member.php?id=${id}`;
        }

        function deleteBeneficiary(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch(`delete_member.php`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ id: id }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire('Deleted!', 'The beneficiary has been deleted.', 'success');
                            location.reload(); // Reload the page to update the table
                        } else {
                            Swal.fire('Failed!', 'There was a problem deleting the beneficiary.', 'error');
                        }
                    })
                    .catch(error => console.error('Error deleting beneficiary:', error));
                }
            });
        }
    </script>
</body>
</html>
